# LeetCode Problem: 9. Palindrome Number
# Difficulty: Easy

def isPalindrome(x):
    return str(x) == str(x)[::-1]
