# LeetCode DSA Practice

This repository contains solutions to easy LeetCode problems for Data Structures and Algorithms practice, focusing on Chapters 1–3.

## Folder Structure
- `Chapter1`: Python basics, arrays, hashmaps
- `Chapter2`: Linked lists and simple data structures
- `Chapter3`: Stacks, strings, parentheses validation

## Problems Solved
| Chapter | Problem                       | Link                                             |
|---------|-------------------------------|--------------------------------------------------|
| 1       | Two Sum                       | https://leetcode.com/problems/two-sum/          |
| 1       | Palindrome Number             | https://leetcode.com/problems/palindrome-number/|
| 2       | Merge Two Sorted Lists        | https://leetcode.com/problems/merge-two-sorted-lists/ |
| 3       | Valid Parentheses             | https://leetcode.com/problems/valid-parentheses/|

## Author
[Urgesa Jemal](https://leetcode.com/UrgesaJemal/)
